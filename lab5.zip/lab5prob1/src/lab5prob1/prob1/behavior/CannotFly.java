package lab5prob1.prob1.behavior;

public class CannotFly implements FlyBehavior {

	@Override
	public void fly() {
		System.out.println(" cannot fly");

	}

}
