package lab5prob1.prob1.behavior;

public interface QuackBehavior {
	public void quack();

}
