package lab5prob1.prob1.behavior;

public class Quack implements QuackBehavior {

	@Override
	public void quack() {
		System.out.println(" quacking");

	}

}
