package lab5prob1.prob1.behavior;

public interface FlyBehavior {

	public void fly();
}
