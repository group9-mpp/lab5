package lab5prob1.prob1.behavior;

public class FlyWithWings implements FlyBehavior {

	@Override
	public void fly() {
		System.out.println(" flying with wings");

	}

}
