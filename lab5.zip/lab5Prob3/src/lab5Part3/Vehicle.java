package lab5Part3;

public interface Vehicle {

	void startEngine();
}
