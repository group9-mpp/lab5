package lab5Part3;

public class ElectricCar implements Vehicle {
	public void startEngine() {
		System.out.print(getClass().getSimpleName());
	}

}
