package lab5prob2;

public interface Figure {
	public double computeArea();
}
